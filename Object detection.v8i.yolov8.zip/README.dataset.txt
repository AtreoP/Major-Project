# Object detection > 2022-04-27 11:20pm
https://universe.roboflow.com/vishi-sapra/object-detection-axukj

Provided by a Roboflow user
License: CC BY 4.0

This car dataset can be used to detect non-commercial four wheeled vehicles of different makes and models from multiple angles.

Use this cars dataset and detection api to create computer vision applications for car counting, traffic density, parking monitoring, and more!

Use your home security camera to detect when parking spots are available using code from this object detection project:
https://blog.roboflow.com/object-tracking-how-to/